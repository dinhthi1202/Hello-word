# -*- coding: utf-8 -*-
from openerp import models, fields, api
class Wizard(models.TransientModel):

    _name = 'hhd_account.journal_wizard'

    def _default_session(self):
        return self.env['account.account'].browse(self._context.get('active_id'))

    account =fields.Many2one('account.account',
        string="Account", required=True, default=_default_session)
    from_date = fields.Date(required=True)
    to_date = fields.Date(required=True)

    @api.model
    def default_get(self, fields):
        res = super(Wizard, self).default_get(fields)
        return res

    def _print_report(self, data):
        print 'print report ',data
        return self.env['report'].get_action(self, 'hhd_account.my_journal', data=data)

    # def _build_contexts(self, data):
    #     result = {}
    #
    #     result['from_date'] = data['form']['from_date'] or False
    #     result['account'] = data['form']['account'] or False
    #     result['to_date'] = data['form']['to_date'] or False
    #     return result

    @api.multi
    def check_report(self):
        self.ensure_one()
        data = {}
        data['ids'] = self.env.context.get('active_ids', [])
        data['model'] = self.env.context.get('active_model', 'ir.ui.menu')
        data['form'] = self.read(['from_date','to_date', 'account'])[0]
        # used_context = self._build_contexts(data)
        # data['form']['used_context'] = dict(used_context, lang=self.env.context.get('lang', 'en_US'))
        print 'check report', data, type(data)
        return self._print_report(data)