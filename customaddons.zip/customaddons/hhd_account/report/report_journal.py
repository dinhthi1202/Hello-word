import time
import datetime
from openerp import api, models


def convert_to_mdy(date):
    d = datetime.datetime.strptime(date, '%Y-%m-%d')
    print datetime.date.strftime(d, "%d-%m-%Y")
    return datetime.date.strftime(d, "%d-%m-%Y")

class JournalReport(models.AbstractModel):
    _name = 'report.hhd_account.my_journal'

    @api.multi
    def render_html(self, data):

        model = self.env.context.get('active_model')
        report_obj = self.env['report']
        print 'model is' , model,type(model), report_obj,type(report_obj)
        account = data['form'].get('account')[0]
        date_from = data['form'].get('from_date')
        date_to = data['form'].get('to_date')
        docs = self.env['account.account'].browse(account)
        print docs
        #filter_account=[('id','=',account)]
        #docs=self.env['account.account'].search(filter_account)
        #print docs
        d = datetime.datetime.now().date()
        # Convert date type from datetime.date type into string
        d1 = datetime.datetime.strftime(d, "%Y-%m-%d")
        d2 = datetime.datetime.strftime(d, "%Y-%m-%d")
        print d1, type(d1),' vs ',date_from,type(date_from)
        print self.env.user.name
        filter1=[
            '&',
                '&',
                    '|',
                        '&', ('account_id', '=', account),
                            ('one_one_entry', '=', True),
                        '&',
                            '|', ('account_id', '=', account),
                                ('corresponding_account_ids', '=', account),
                            ('has_one_corresponding_account', '=', True),
                    ('date','>=',str(date_from)),
                ('date', '<=', str(date_to))

        ]
        # comparion date field may be error (diffent format)
        filter = ['|',
                    '&', ('account_id', '=', account),
                        ('one_one_entry', '=', True),
                    '&',
                    '|', ('account_id', '=', account),
                  ('corresponding_account_ids', '=', account),
                  ('has_one_corresponding_account', '=', True)]

        account_move_lines = self.env['account.move.line'].search(filter1)
        print 'wwwwwwwwwwwineswwww', account_move_lines, type(account_move_lines)
        #for account_move_line in account_move_lines:
        #   print account_move_line


        docargs = {
            'doc_ids': self.ids,
            'doc_model': model,
            'docs': docs,
            'data': data['form'],
            'time': 'time',
            'account_move_lines':account_move_lines,
            'convert_to_mdy':convert_to_mdy,
        }
        return report_obj.render('hhd_account.my_journal', docargs)

