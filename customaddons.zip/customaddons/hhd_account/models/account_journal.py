# -*- coding: utf-8 -*-
from openerp import api, fields, models, _


class AccountJournal(models.Model):
    _name = 'account.journal'
    _inherit = ['account.journal', 'mail.thread']

    hhd_credit_account_id = fields.Many2one('account.account', string='HHD Credit Account',
                                            domain=[('deprecated', '=', False)],
                                            help="It acts as a hhd account for credit amount")
    hhd_debit_account_id = fields.Many2one('account.account', string='HHD Debit Account',
                                           domain=[('deprecated', '=', False)],
                                           help="It acts as a hhd account for debit amount")
    reciprocal_account = fields.Boolean(string="Reciprocal Account")
    date_open = fields.Date(string="Date Open")

    journal_not_m2m = fields.Boolean(string="Journal Not M2M", default=1,
                                     help="Journal not input n - n in account_move_line.")