# -*- coding: utf-8 -*-
from openerp import api, fields, models, _
import openerp.addons.decimal_precision as dp


class ResCurrencyRate(models.Model):
    _inherit = 'res.currency.rate'

    rate = fields.Float('Rate', digits=dp.get_precision('Currency Rate'), help='The rate of the currency to the currency of rate 1')