# -*- coding: utf-8 -*-
from openerp import api, fields, models, _
from openerp.exceptions import UserError, ValidationError
import openerp.addons.decimal_precision as dp


class AccountPayment(models.Model):
    _inherit = "account.payment"
    _order = 'id desc'

    origin = fields.Char(string='Source Document',
                         help="Reference of the document that produced this invoice.",
                         readonly=True, states={'draft': [('readonly', False)]})

    analytic_account_id = fields.Many2one('account.analytic.account', string='Analytic Account')
    journal_id = fields.Many2one('account.journal', string='Payment Method', required=True,
                                 domain=[('type', 'in', ('bank', 'cash', 'general'))])

    @api.multi
    def post(self):
        res = super(AccountPayment, self).post()
        for record in self:
            line_ids = self.env['account.move.line'].search([('payment_id', '=', record.id)])
            if line_ids and record.analytic_account_id:
                for line in line_ids:
                    if record.destination_account_id.id == line.account_id.id:
                        line.write({'analytic_account_id': record.analytic_account_id.id})
                line_ids.create_analytic_lines()
        return res

    @api.onchange('payment_type')
    def _onchange_payment_type(self):
        res = super(AccountPayment, self)._onchange_payment_type()
        for i, domain in enumerate(res['domain']['journal_id']):
            if 'type' in domain:
                res['domain']['journal_id'][i] = ('type', 'in', ('bank', 'cash', 'general'))
        return res

    # get mail follower from journal into payment
    @api.model
    def create(self, vals):
        res = super(AccountPayment, self).create(vals)
        if res.journal_id:
            document = self.env['account.payment'].browse(res.id)
            partner_ids = [mail.partner_id.id for mail in res.journal_id.message_follower_ids]
            document.message_subscribe(partner_ids)
        return res

    # action confirm many payment
    @api.multi
    def confirm_payment(self):
        for record in self:
            record.post()

    @api.one
    @api.depends('invoice_ids', 'payment_type', 'partner_type', 'partner_id')
    def _compute_destination_account_id(self):
        if self.invoice_ids:
            self.destination_account_id = self.invoice_ids[0].account_id.id
        elif self.payment_type == 'transfer':
            if not self.company_id.transfer_account_id.id:
                raise UserError(_('Transfer account not defined on the company.'))
            self.destination_account_id = self.company_id.transfer_account_id.id
        elif self.partner_id:
            if self.partner_type == 'customer':
                if self.journal_id.reciprocal_account:
                    if self.journal_id.hhd_credit_account_id:
                        self.destination_account_id = self.journal_id.hhd_credit_account_id.id
                    else:
                        self.destination_account_id = self.partner_id.property_account_receivable_id.id
                else:
                    self.destination_account_id = self.partner_id.property_account_receivable_id.id
            else:
                if self.journal_id.reciprocal_account:
                    if self.journal_id.hhd_debit_account_id:
                        self.destination_account_id = self.journal_id.hhd_debit_account_id.id
                    else:
                        self.destination_account_id = self.partner_id.property_account_payable_id.id
                else:
                    self.destination_account_id = self.partner_id.property_account_payable_id.id

    def _compute_total_invoices_amount(self):
        """ Compute the sum of the residual of invoices, expressed in the payment currency """
        payment_currency = self.currency_id or self.journal_id.currency_id or self.journal_id.company_id.currency_id or self.env.user.company_id.currency_id
        invoices = self._get_invoices()

        if all(inv.currency_id == payment_currency for inv in invoices):
            total = sum(invoices.mapped('residual_signed'))
        else:
            total = 0
            for inv in invoices:
                if inv.company_currency_id != payment_currency:
                    total += inv.company_currency_id.with_context(date=self.payment_date).compute(
                        inv.residual_company_signed, payment_currency)
                else:
                    total += inv.residual_company_signed
        return abs(total)