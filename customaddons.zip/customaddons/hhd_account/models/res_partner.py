from openerp import models, fields, api
from openerp.exceptions import UserError
from openerp.addons.base_vat.base_vat import res_partner as Home


class ResPartner(Home):
    _inherit = 'res.partner'

    def check_vat(self, cr, uid, ids, context=None):
        return True

    def _construct_constraint_msg(self, cr, uid, ids, context=None):
        return True

    _constraints = [(check_vat, _construct_constraint_msg, ["vat"])]
