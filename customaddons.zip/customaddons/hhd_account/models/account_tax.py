# -*- coding: utf-8 -*-
from openerp import api, fields, models, _


class AccountTax(models.Model):
    _inherit = 'account.tax'

    extra_provincial_tax = fields.Boolean(string="Extra Provincial Tax")
