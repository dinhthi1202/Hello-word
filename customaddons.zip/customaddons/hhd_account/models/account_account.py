# -*- coding: utf-8 -*-
from openerp import api, fields, models, _
from openerp.exceptions import UserError, ValidationError


class AccountAccount(models.Model):
    _inherit = "account.account"

    def _compute_total_amount(self):
        for record in self:
            amount = 0.0
            cr = self.env.cr
            cr.execute("""
                SELECT sum(credit) as credit, sum(debit) as debit
                FROM account_move_line as aml
                JOIN account_move am ON am.id = aml.move_id
                WHERE aml.account_id = %s
                AND am.state = 'posted'
            """, (record.id,))
            result = cr.dictfetchall()
            if result[0]['debit'] is not None and result[0]['credit'] is not None:
                amount = result[0]['debit'] - result[0]['credit']

            record.total_amount = amount

    send_sms = fields.Boolean(string="Send SMS")
    send_email = fields.Boolean(string="Send Email")
    total_amount = fields.Monetary(compute="_compute_total_amount", string="Total Amount")
    corresponding_account_ids = fields.Many2many('account.account', 'account_corresponding_tb_rel',
                                                 'account_id', 'corresponding_id', string="Corresponding Account")
    reconcile_not_partner = fields.Boolean(string="Forced Reconcile Not Check Partner")
    required_partner = fields.Boolean(string="Required Partner")
    required_product = fields.Boolean(string="Required Product")

    @api.multi
    def name_get(self):
        result = super(AccountAccount, self).name_get()
        # add company_registry in name_get
        for idx, val in enumerate(result):
            account_id = self.env['account.account'].browse(val[0])
            if account_id and account_id.company_id.company_registry:
                result[idx] = (val[0], val[1] + ' ' + account_id.company_id.company_registry)
        return result

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100):
        domain = [('deprecated', '=', False)]
        return super(AccountAccount, self).name_search(name, args=domain+args, operator=operator, limit=limit)

