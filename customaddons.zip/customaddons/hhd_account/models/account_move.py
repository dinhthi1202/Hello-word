# -*- coding: utf-8 -*-
from openerp import api, fields, models, _
from openerp.exceptions import UserError, ValidationError
from datetime import datetime
from dateutil import relativedelta
from itertools import izip, groupby
from openerp.tools import float_compare


class AccountMove(models.Model):
    _inherit = 'account.move'
    _order = 'id desc'

    open_journal = fields.Boolean(string="Open Journal")
    check_adjusted = fields.Boolean(string="Adjusted")
    date_adjusted = fields.Date(string="Date Adjusted")

    def _compute_email_to(self):
        for record in self:
            company_id = record.company_id
            if company_id.director:
                record.email_to = company_id.director.work_email

    # auto get email to send mail
    email_to = fields.Text('Email to', readonly=True, compute='_compute_email_to')

    @api.multi
    def repair_data_tranfer_sms(self, move_line_id):
        account_id = move_line_id.account_id
        return "Account " + account_id.name + "-" + account_id.code + ": " + "Debit: " +\
               str(move_line_id.debit) + ".Credit: " + str(move_line_id.credit) + ".Amount remain: " +\
               str(account_id.total_amount)

    @api.multi
    def post(self):
        prec = self.env['decimal.precision'].precision_get('Account')
        for move in self:
            groups = groupby(move.line_ids, lambda a: a.group_line)
            check_m2m = move.journal_id.journal_not_m2m
            for num, lines in groups:
                lines = list(lines)
                if check_m2m:
                    credit_line_count = sum(1 for line in lines if line.credit != 0)
                    debit_line_count = len(list(lines)) - credit_line_count
                    if credit_line_count > 1 and debit_line_count > 1:
                        raise UserError(_("""You can't input many credit - many debit in group %s.
                            You only input one credit - one debit, one credit - many debit and one debit - many credit.""") % (num, ))
                data = [(line.credit, line.debit) for line in lines]
                tuple_compare = map(sum, izip(*data))
                if float_compare(tuple_compare[0], tuple_compare[1], prec) != 0:
                    raise UserError(_('Credit and Debit not equal in each group! Please try input again.'))
        res = super(AccountMove, self).post()
        self.send_messages()
        return res

    @api.multi
    def send_messages(self):
        for move in self:
            flag = False
            for line in move.line_ids:
                if line.account_id.send_sms:
                    # data transfer sms
                    list_phone = []
                    company_id = move.company_id
                    if company_id.director:
                        list_phone.append(company_id.director.mobile_phone)

                    data = self.repair_data_tranfer_sms(line)
                    # if list_phone:
                    #     self.env['sms.queue'].send_sms(list_phone, data)
                if line.account_id.send_email:
                    flag = True
            if flag and move.email_to:
                ir_model_data = self.env['ir.model.data']
                try:
                    template_id = ir_model_data.get_object_reference('hhd_account',
                                                                     'email_template_account_payment_change')[1]
                except ValueError:
                    template_id = False
                self.env['mail.template'].browse(template_id).send_mail(move.id, force_send=True)


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'
    _order = "date desc, id desc"

    @api.multi
    @api.depends('date', 'date_maturity')
    def _compute_date_subtract(self):
        for record in self:
            date = datetime.strptime(record.date, '%Y-%m-%d')
            due_date = datetime.strptime(record.date_maturity, '%Y-%m-%d')
            r = relativedelta.relativedelta(due_date, date)
            if r.days < 10:
                record.date_subtract = r.months + (float(r.days) / 10)
            else:
                record.date_subtract = r.months + (float(r.days) / 100)

    @api.multi
    @api.depends('move_id.line_ids')
    def compute_corresponding_account_ids(self):
        for record in self:
            x = 'debit' if record.debit == 0.0 else 'credit'
            same_group_line_ids = record.move_id.line_ids.filtered(lambda x: x.group_line == record.group_line)
            record.corresponding_account_ids = [(6, 0, [line.account_id.id for line in same_group_line_ids if getattr(line, x) != 0.0])]
            record.has_one_corresponding_account = len(record.corresponding_account_ids) == 1
            record.one_one_entry = len(same_group_line_ids) == 2

    # group debit - credit if many - many credit, debit
    group_line = fields.Integer(string="Group", default=0)
    has_one_corresponding_account = fields.Boolean('Has One Corresponding Account', compute=compute_corresponding_account_ids, store=True)
    #TK DU
    corresponding_account_ids = fields.Many2many('account.account', compute=compute_corresponding_account_ids,
                                                 string="Corresponding Account", store=True)
    one_one_entry = fields.Boolean('One One Entry', compute=compute_corresponding_account_ids, store=True)
    # date - due_date, use in balance sheet report when domain short-term, long-term
    date_subtract = fields.Float(compute="_compute_date_subtract", string="Date Subtract", store=True, digits=(2, 2))

    @api.multi
    def write(self, vals):
        for record in self:
            account_id = record.account_id.id
            if 'account_id' in vals:
                account_id = vals['account_id']
            account_id = self.env['account.account'].browse(account_id)
            if account_id and account_id.required_partner:
                if 'partner_id' in vals and not vals['partner_id']:
                    raise UserError(_('Account %s must input partner.') % (account_id.code + ' ' + account_id.name,))

            if account_id and account_id.required_product:
                if 'product_id' in vals and not vals['product_id']:
                    raise UserError(_('Account %s must input product.') % (account_id.code + ' ' + account_id.name,))

        return super(AccountMoveLine, self).write(vals)

    # copy add follower from account_payment, account_invoice to account_move_line
    @api.model
    def create(self, vals):
        if 'account_id' in vals and vals['account_id']:
            account_id = self.env['account.account'].browse(vals['account_id'])
            if account_id and account_id.required_partner:
                if 'partner_id' not in vals:
                    raise UserError(_('Account %s must input partner.') % (account_id.code + ' ' + account_id.name,))
                else:
                    if not vals['partner_id']:
                        raise UserError(_('Account %s must input partner.') % (account_id.code + ' ' + account_id.name,))

            if account_id and account_id.required_product:
                if 'product_id' not in vals:
                    raise UserError(_('Account %s must input product.') % (account_id.code + ' ' + account_id.name,))
                else:
                    if not vals['product_id']:
                        raise UserError(_('Account %s must input product.') % (account_id.code + ' ' + account_id.name,))

        return super(AccountMoveLine, self).create(vals)

    @api.multi
    def reconcile(self, writeoff_acc_id=False, writeoff_journal_id=False):
        #Perform all checks on lines
        company_ids = set()
        all_accounts = []
        partners = set()
        for line in self:
            company_ids.add(line.company_id.id)
            all_accounts.append(line.account_id)
            if (line.account_id.internal_type in ('receivable', 'payable')):
                if not line.account_id.reconcile_not_partner:
                    partners.add(line.partner_id.id)
            if line.reconciled:
                raise UserError(_('You are trying to reconcile some entries that are already reconciled!'))
        if len(company_ids) > 1:
            raise UserError(_('To reconcile the entries company should be the same for all entries!'))
        if len(set(all_accounts)) > 1:
            raise UserError(_('Entries are not of the same account!'))
        if not all_accounts[0].reconcile:
            raise UserError(_('The account %s (%s) is not marked as reconciliable !') % (all_accounts[0].name, all_accounts[0].code))
        if len(partners) > 1:
            raise UserError(_('The partner has to be the same on all lines for receivable and payable accounts!'))

        #reconcile everything that can be
        remaining_moves = self.auto_reconcile_lines()

        #if writeoff_acc_id specified, then create write-off move with value the remaining amount from move in self
        if writeoff_acc_id and writeoff_journal_id and remaining_moves:
            writeoff_to_reconcile = remaining_moves._create_writeoff({'account_id': writeoff_acc_id.id, 'journal_id': writeoff_journal_id.id})
            #add writeoff line to reconcile algo and finish the reconciliation
            remaining_moves = (remaining_moves + writeoff_to_reconcile).auto_reconcile_lines()

        account_move_ids = [l.move_id.id for l in self if l.move_id.matched_percentage == 1]
        if account_move_ids:
            expenses = self.env['hr.expense'].search([('account_move_id', 'in', account_move_ids)])
            expenses.paid_expenses()

