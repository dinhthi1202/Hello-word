# -*- coding: utf-8 -*-
from openerp import api, fields, models, _
import openerp.addons.decimal_precision as dp
from openerp.exceptions import UserError


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'
    _order = 'id desc'

    # add readonly=False
    origin = fields.Char(string='Source Document', help="Reference of the document that produced this invoice.",
                         readonly=False)
    invoice_partner_id = fields.Many2one('res.partner', string="Invoice Partner")

    sale_id = fields.Many2one('sale.order', string='Add Sale Order',
                              help='Encoding help. When selected, the associated sale order lines are added to the \
                                   customer invoice. Several SO can be selected.')
    # add copy = False
    invoice_line_ids = fields.One2many('account.invoice.line', 'invoice_id', string='Invoice Lines',
                                       oldname='invoice_line',
                                       readonly=True, states={'draft': [('readonly', False)]}, copy=False)

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        for record in self:
            record.invoice_partner_id = record.partner_id.id
        return super(AccountInvoice, self)._onchange_partner_id()

    @api.multi
    def register_payment(self, payment_line, writeoff_acc_id=False, writeoff_journal_id=False):
        if self:
            return super(AccountInvoice, self).register_payment(payment_line, writeoff_acc_id, writeoff_journal_id)
        else:
            return True

    @api.multi
    def invoice_validate(self):
        for record in self:
            if record.reference:
                invoice_id = self.env['account.invoice'].search([('company_id', '=', record.company_id.id),
                                                                 ('date_invoice', '=', record.date_invoice),
                                                                 ('reference', '=', record.reference),
                                                                 ('partner_id', '=', record.partner_id.id),
                                                                 ('type', '=', record.type),
                                                                 ('id', '!=', record.id)], limit=1)
                if invoice_id:
                    raise UserError(_('You input reference same invoice %s .Please check again !!!') % (invoice_id.number if invoice_id.number else invoice_id.id,))
        return super(AccountInvoice, self).invoice_validate()

    @api.onchange('state', 'partner_id', 'invoice_line_ids')
    def _onchange_allowed_purchase_ids(self):
        res = super(AccountInvoice, self)._onchange_allowed_purchase_ids()
        domain = [('invoice_status', '=', 'to invoice'),
                  ('partner_id', 'child_of', self.partner_id.id),
                  ('pricelist_id.currency_id', '=', self.currency_id.id)]
        sale_line_ids = self.invoice_line_ids.mapped('sale_line_ids')
        if sale_line_ids:
            sale_ids = [line.order_id.id for line in sale_line_ids]
            domain.append(('id', 'not in', sale_ids))

        res['domain'].update({'sale_id': domain})
        return res

    def _prepare_invoice_line_from_so_line(self, line, sale_id):
        qty = line.qty_to_invoice
        if self.type == 'out_refund':
            if 'qty_to_refund_inv' in self.env['sale.order.line'].fields_get():
                qty = line.qty_to_refund_inv

        currency_id = False
        taxes = line.tax_id
        invoice_line_tax_ids = taxes
        if sale_id.fiscal_position_id:
            invoice_line_tax_ids = sale_id.fiscal_position_id.map_tax(taxes)
        invoice_line = self.env['account.invoice.line']
        if sale_id.pricelist_id:
            currency_id = sale_id.pricelist_id.currency_id

        data = {
            'sale_line_ids': [(6, 0, [line.id])],
            'name': line.name,
            'origin': sale_id.origin,
            'uom_id': line.product_uom.id or False,
            'product_id': line.product_id.id,
            'account_id': invoice_line.with_context({'journal_id': self.journal_id.id, 'type': 'out_invoice'})._default_account(),
            'price_unit': currency_id.compute(line.price_unit, self.currency_id,
                                              round=False) if currency_id else line.price_unit,
            'quantity': qty,
            'discount': line.discount,
            'account_analytic_id': sale_id.project_id and sale_id.project_id.id or False,
            'invoice_line_tax_ids': invoice_line_tax_ids.ids,
        }
        account = invoice_line.get_invoice_line_account('out_invoice', line.product_id,
                                                        sale_id.fiscal_position_id, self.env.user.company_id)
        if account:
            data['account_id'] = account.id
        return data

    @api.onchange('sale_id')
    def onchange_sale_id(self):
        if not self.sale_id:
            return {}
        if not self.partner_id:
            self.partner_id = self.sale_id.partner_id.id

        new_lines = self.env['account.invoice.line']
        for line in self.sale_id.order_line:
            # Load a SO line only once
            if line in self.invoice_line_ids.mapped('sale_line_ids'):
                continue
            data = self._prepare_invoice_line_from_so_line(line, self.sale_id)
            new_line = new_lines.new(data)
            new_line._set_additional_fields(self)
            new_lines += new_line

        self.invoice_line_ids += new_lines
        self.sale_id = False
        return {}

    @api.onchange('currency_id')
    def _onchange_currency_id(self):
        if self.currency_id and self.invoice_line_ids:
            for line in self.invoice_line_ids.filtered(lambda r: r.sale_line_ids):
                line.price_unit = line.sale_line_ids[0].order_id.pricelist_id.currency_id.compute(
                    line.sale_line_ids[0].price_unit, self.currency_id, round=False)
        return super(AccountInvoice, self)._onchange_currency_id()

    @api.onchange('invoice_line_ids')
    def _onchange_origin(self):
        sale_ids = self.env['sale.order']
        for inv_line in self.invoice_line_ids:
            for line in inv_line.sale_line_ids:
                sale_ids |= line.order_id
        if sale_ids:
            self.origin = ', '.join(sale_ids.mapped('name'))
        return super(AccountInvoice, self)._onchange_origin()


class AccountInvoiceLine(models.Model):
    _inherit = "account.invoice.line"
    _order = 'invoice_id desc, id'

    @api.onchange('quantity')
    def onchange_quantity(self):
        if self.invoice_id.type in ['in_invoice', 'out_invoice']:
            if self.purchase_line_id:
                if self.product_id.purchase_method == 'purchase':
                    qty_to_invoice = self.purchase_line_id.product_qty - self.purchase_line_id.qty_invoiced + self._origin.quantity
                else:
                    qty_to_invoice = self.purchase_line_id.qty_received - self.purchase_line_id.qty_invoiced + self._origin.quantity

                if qty_to_invoice < 0:
                    warning = {}
                    title = _("Warning for %s") % self.product_id.name
                    message = _('You input quantity product over quantity in purchase order, \
                    %s is the largest quantity product to invoice.') % (qty_to_invoice + self.quantity)
                    warning['title'] = title
                    warning['message'] = message
                    self.quantity = self._origin.quantity
                    return {'warning': warning}
            if self.sale_line_ids:
                qty_to_invoice = sum([line.qty_to_invoice for line in self.sale_line_ids]) + self._origin.quantity
                if qty_to_invoice < 0:
                    warning = {}
                    title = _("Warning for %s") % self.product_id.name
                    message = _('You input quantity product over quantity in sale order, \
                    %s is the largest quantity product to invoice.') % (qty_to_invoice + self.quantity)
                    warning['title'] = title
                    warning['message'] = message
                    self.quantity = self._origin.quantity
                    return {'warning': warning}
        # elif self.invoice_id.type in ['in_refund', 'out_refund']:
        #     if self.purchase_line_id:
        #         if 'qty_refund' in self.env['purchase.order.line'].fields_get() and 'qty_refund_inv' in self.env['purchase.order.line'].fields_get():
        #             qty_to_invoice = self.purchase_line_id.qty_refund - self.purchase_line_id.qty_refund_inv + self._origin.quantity
        #
        #             if qty_to_invoice < 0:
        #                 warning = {}
        #                 title = _("Warning for %s") % self.product_id.name
        #                 message = _('You input quantity product over quantity in purchase order, \
        #                 %s is the largest quantity product to invoice.') % (qty_to_invoice + self.quantity)
        #                 warning['title'] = title
        #                 warning['message'] = message
        #                 self.quantity = self._origin.quantity
        #                 return {'warning': warning}
        #     if self.sale_line_ids:
        #         if 'qty_to_refund_inv' in self.env['sale.order.line'].fields_get():
        #             qty_to_invoice = sum([line.qty_to_refund_inv for line in self.sale_line_ids]) + self._origin.quantity
        #             if qty_to_invoice < 0:
        #                 warning = {}
        #                 title = _("Warning for %s") % self.product_id.name
        #                 message = _('You input quantity product over quantity in sale order, \
        #                 %s is the largest quantity product to invoice.') % (qty_to_invoice + self.quantity)
        #                 warning['title'] = title
        #                 warning['message'] = message
        #                 self.quantity = self._origin.quantity
        #                 return {'warning': warning}
