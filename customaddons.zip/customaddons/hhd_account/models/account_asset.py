# -*- coding: utf-8 -*-
from openerp import api, fields, models, _
from lxml import etree


class AccountAssetAsset(models.Model):
    _inherit = 'account.asset.asset'
    _order = 'id desc'

    move_line_id = fields.Many2one('account.move.line', string="Account")
    account_asset_id = fields.Many2one('account.account', related="category_id.account_depreciation_id", string='Asset Account')

    @api.onchange('category_id')
    def onchange_category_id(self):
        super(AccountAssetAsset, self).onchange_category_id()
        for record in self:
            if record.category_id:
                list_account = []
                asset_ids = self.env['account.asset.asset'].search([('move_line_id', '!=', False)])
                if asset_ids:
                    for ass in asset_ids:
                        list_account.append(ass.move_line_id.id)
                return {'domain': {'move_line_id': [('account_id', '=', record.category_id.account_depreciation_id.id),
                                                    ('debit', '>', 0),
                                                    ('id', 'not in', list_account)]}}

    @api.onchange('move_line_id')
    def onchange_move_line_id(self):
        for record in self:
            record.value = record.move_line_id.debit

    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        res = super(AccountAssetAsset, self).fields_view_get(
            view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu)

        list_account = []
        asset_ids = self.env['account.asset.asset'].search([('move_line_id', '!=', False)])
        if asset_ids:
            for ass in asset_ids:
                list_account.append(ass.move_line_id.id)

        doc = etree.XML(res['arch'])
        for node in doc.xpath("//field[@name='move_line_id']"):
            user_filter = "[('id', 'not in'," + str(list_account) + " ),('account_id', '=', account_asset_id),('debit', '>', 0)]"
            node.set('domain', user_filter)
        res['arch'] = etree.tostring(doc)
        return res


