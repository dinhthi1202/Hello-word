# -*- coding: utf-8 -*-

from openerp import models, fields, api

class Course(models.Model):
    _name = 'openacademy.course'

    name = fields.Char(string="Title", required=True)
    description = fields.Text("Des")
    description2 = fields.Text("Des2")
    calories = fields.Integer("Calories")
    responsible_id = fields.Many2one('res.users',
        ondelete='set null', string="Responsible", index=True)
    session_ids = fields.One2many(
        'openacademy.session', 'course_id', string="Sessions")

class Session(models.Model):
    _name = 'openacademy.session'

    name = fields.Char(required=True)
    start_date = fields.Date()
    end_date = fields.Date()
    duration = fields.Float(digits=(6, 2), help="Duration in days")
    seats = fields.Integer(string="Number of seats")
    instructor_id = fields.Many2one('res.partner', string="Instructor")
    course_id = fields.Many2one('openacademy.course',
                                ondelete='cascade', string="Course", required=True)
    attendee_ids = fields.Many2many('res.partner', string="Attendees")

    @api.multi
    def print_report(self):

        print 'multi is ', self
        self.ensure_one()
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('openacademy.report_session_view')
        docs = self.env['openacademy.session'].search([])
        print 'wwwwwwwwwwwwwww', docs, type(docs)
        docargs = {
            'doc_ids': 'docids',
            'doc_model': report.model,
            'docs': docs,
        }
        print "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWiiiiiiiiiiiiiiiiiiiiiiii"

        return report_obj.render('openacademy.report_session_view', docargs)


'''
    @api.multi
    def print_report(self, docids):
        self.ensure_one()
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('openacademy.report_session_view')
        docargs = {
            'doc_ids': docids,
            'doc_model': report.model,
            'docs': self,
        }
        print "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWiiiiiiiiiiiiiiiiiiiiiiii"
        return report_obj.render('openacademy.report_session_view', docargs)
'''
class ParticularReport(models.AbstractModel):
    _name = 'report.openacademy.report_session_view'
    @api.model
    def render_html(self, docids, data=None):
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('openacademy.report_session_view')
        docs=self.env['openacademy.session'].search([])

        print 'wwwwwwwwwwwwwww', docs, type(docs)
        docargs = {
            'doc_ids': docids,
            'doc_model': report.model,
            'docs': docs,
        }
        return report_obj.render('openacademy.report_session_view', docargs)
