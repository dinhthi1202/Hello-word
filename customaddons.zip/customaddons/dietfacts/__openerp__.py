{
	'name':"DietFacts",
	'version':"1.0",
	'description':'Adds nutrition information to products',
	'author':"??",
	'depends':['sale'],
	'data': [
		'views/product_template_view.xml'
	],
	'installable': True,
}
