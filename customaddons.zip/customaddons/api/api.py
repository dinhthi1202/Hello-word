import xmlrpclib
import csv
server = 'http://localhost:8069'
db = 'test'
username = 'thitran@hhdgroup.com'
password = '123'
common = xmlrpclib.ServerProxy('{}/xmlrpc/2/common'.format(server),allow_none=True)
print common.version()
uid = common.authenticate(db, username, password, {})
models = xmlrpclib.ServerProxy('{}/xmlrpc/2/object'.format(server),allow_none=True)
filter=[[('product.template','=','')]]
product_count = models.execute_kw(db, uid, password,'product.template', 'search_count',[[]])
print product_count